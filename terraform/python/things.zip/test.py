def main():
    print ("hello world")
    name = input ("what is your name \n")
    print ("your name is", name)

if __name__ == "__main__":
    main()
    
a = '*'    
b = '*'    
for i in range (5):
    print (a)
    a = a + b