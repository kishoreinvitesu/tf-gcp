
import math;

def main():
    x = 0
    while (x<5):
        print (x)
        x = x+1
    
    for y in range (1, 6):
        print (y)
        
    days = ["mon", "tue", "wed", "thu", "fri", "sat", "sun"]
    
    for z in days:
        print (z)
    
    print (math.sqrt(9))      
main()


    